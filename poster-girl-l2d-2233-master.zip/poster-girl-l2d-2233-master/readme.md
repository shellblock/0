# poster-girl-l2d-2233
2233娘的 Live2D 看板娘插件(WordPress)！

[Demo: https://www.fczbl.vip/946.html](https://www.fczbl.vip/946.html)

## 警告
本人不对 R18 模型造成的任何影响/后果负责

## 使用方法
1. Star 本项目

2. Download ZIP, 解压

3. 上传至站点 `/wp-content/plugins` 目录下

4. 登录后台启用即可

## 使用须知
插件需要 jQuery 和 Font Awesome 的支持，如果你的主题没有这两个东西，请去插件设置页面启用一下

IIS用户需要添加下列MIME类型才可以正常使用：.json/.moc/.mtn

## 授权
由于原项目使用 GPL 2.0 协议，故本项目也采用相同的开源协议进行授权。

另，2233 版权归 bilibili 所有！

原创不易！如果喜欢本项目，请 Star 它以示对我的支持~

## 使用的开源项目
 - [Live2D-Src](https://github.com/journey-ad/live2d_src)